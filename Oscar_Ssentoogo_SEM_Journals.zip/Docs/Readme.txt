- Instructions to install and configure any prerequisites or dependencies
- Instructions to create and initialize the database
- Instructions to configure and prepare the source code to build and run properly
- Assumptions you have made - it is good to explain your thought process and the assumptions you have made
- Any issues you have faced while completing the assignment
- Any constructive feedback for improving the assignment

???
